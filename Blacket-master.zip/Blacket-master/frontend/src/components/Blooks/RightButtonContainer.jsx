import styles from "@styles";

export default function RightButtonContainer({ children }) {
    return <div className={styles.blooks.rightButtonContainer}>{children}</div>;
}