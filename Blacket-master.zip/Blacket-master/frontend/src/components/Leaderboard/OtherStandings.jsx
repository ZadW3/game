import styles from "@styles";

export default function OtherStandings({ children }) {
    return <div className={styles.leaderboard.otherStandings}>{children}</div>;
}