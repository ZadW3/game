import styles from "@styles";

export default function OtherTopThree({ children }) {
    return <div className={styles.leaderboard.otherTopThreeStandings}>{children}</div>
}