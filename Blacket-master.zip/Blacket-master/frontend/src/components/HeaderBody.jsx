import styles from "@styles";

export default function HeaderBody({ children }) {
    return <div className={styles.all.headerBody}>{children}</div>;
}