import AgreeHolder from "./AgreeHolder";
import Container from "./Container";
import Header from "./Header";
import ErrorContainer from "./ErrorContainer";
import SubmitButton from "./SubmitButton";

export {
    AgreeHolder,
    Container,
    Header,
    ErrorContainer,
    SubmitButton
}