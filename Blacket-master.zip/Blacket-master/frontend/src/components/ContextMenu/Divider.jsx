import styles from "@styles";

export default function Divider() {
    return <div className={styles.contextMenu.divider} />;
}