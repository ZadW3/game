import OtpModal from "./OtpModal";

export {
    OtpModal
}