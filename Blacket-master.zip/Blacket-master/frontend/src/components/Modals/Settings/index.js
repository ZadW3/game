import ChangePasswordModal from "./ChangePasswordModal";
import ChangeUsernameModal from "./ChangeUsernameModal";
import DisableOTPModal from "./DisableOTPModal";
import EnableOTPModal from "./EnableOTPModal";

export {
    ChangePasswordModal,
    ChangeUsernameModal,
    DisableOTPModal,
    EnableOTPModal
}