import styles from "@styles";

export default function SidebarBody({ children }) {
    return <div className={styles.all.sidebarBody}>{children}</div>;
}