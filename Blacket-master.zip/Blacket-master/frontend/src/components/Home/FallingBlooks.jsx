import styles from "@styles";

export default function FallingBlooks() {
    return <img src="/content/fallingBlooks.png" alt="Blooks" className={styles.home.headerImage} draggable="false" />;
}