import styles from "@styles";

export default function Divider() {
    return <div className={styles.home.headerSide} />;
}