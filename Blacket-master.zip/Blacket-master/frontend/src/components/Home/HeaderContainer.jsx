import styles from "@styles";

export default function HeaderContainer({ children }) {
    return <div className={styles.home.headerContainer}>{children}</div>;
}