import styles from "@styles";

export default function ButtonHolder({ children }) {
    return <div className={styles.market.buttonHolder}>{children}</div>;
}