import styles from "@styles";

export default function PacksWrapper({ children }) {
    return <div className={styles.market.packsWrapper}>{children}</div>;
}