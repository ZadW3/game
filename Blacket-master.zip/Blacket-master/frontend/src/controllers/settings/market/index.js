import useOpenPacksInstantly from "./useOpenPacksInstantly";

export {
    useOpenPacksInstantly
}