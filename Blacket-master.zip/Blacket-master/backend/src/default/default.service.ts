import { Injectable } from "@nestjs/common";

@Injectable()
export class DefaultService {

    async get() {
        return;
    }
}
