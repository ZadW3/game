export default [
    process.env.VITE_INFORMATION_NAME,
    "",
    "me"
]