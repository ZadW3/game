export default [
    "anal",
    "anus",
    "arse",
    "dick",
    "pussy",
    "fuck",
    "bitch",
    "nigger",
    "nigga",
    "tranny",
    "trannie",
    "fag",
    "slut"
]